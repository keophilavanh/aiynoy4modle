#
# TABLE STRUCTURE FOR: tb_employee
#

DROP TABLE IF EXISTS `tb_employee`;

CREATE TABLE `tb_employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_fname` varchar(25) NOT NULL,
  `emp_lname` varchar(25) DEFAULT NULL,
  `emp_phone` varchar(13) DEFAULT NULL,
  `emp_address` varchar(100) DEFAULT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `permission` varchar(25) NOT NULL,
  `Date_login` date DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tb_employee` (`emp_id`, `emp_fname`, `emp_lname`, `emp_phone`, `emp_address`, `username`, `password`, `permission`, `Date_login`) VALUES (1, 'ໂຊກໄຊ', 'ແກ້ວພິລາວັນ', '8552077452952', 'ບ້ານ ດອນກອຍ ເມືອງສີສັດຕະນາກ ນະຄອນຫຼວງວຽງຈັນ', 'Admin', 'QWRtaW4=', 'Admin', '2019-12-12');
INSERT INTO `tb_employee` (`emp_id`, `emp_fname`, `emp_lname`, `emp_phone`, `emp_address`, `username`, `password`, `permission`, `Date_login`) VALUES (2, 'ແມັກກີ້', 'ວັງວຽງ', '7777777', 'ວັງວຽງ', 'max', 'MTIzNDU=', 'Employee', NULL);
INSERT INTO `tb_employee` (`emp_id`, `emp_fname`, `emp_lname`, `emp_phone`, `emp_address`, `username`, `password`, `permission`, `Date_login`) VALUES (3, 'asdasd', 'asdasd', 'asdasd', 'asdasd', 'aaaaaaaa', 'YWFhYWFhYWFhYQ==', 'Admin', NULL);


#
# TABLE STRUCTURE FOR: tb_users
#

DROP TABLE IF EXISTS `tb_users`;

CREATE TABLE `tb_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) NOT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_phone` varchar(13) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `permission` varchar(25) NOT NULL,
  `Date_login` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (1, 'ໂຊກໄຊ', 'ແກ້ວພິລາວັນ', '8552077452952', 'ບ້ານ ດອນກອຍ ເມືອງສີສັດຕະນາກ ນະຄອນຫຼວງວຽງຈັນ', 'Admin', 'QWRtaW4=', 'Admin', '2019-12-12');
INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (2, 'ແມັກກີ້', 'ວັງວຽງ', '7777777', 'ວັງວຽງ', 'max', 'MTIzNDU=', 'Employee', NULL);
INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (4, 'sdsa', 'asd', '6556', 'asdasd', 'asdas', 'YXNkYXM=', 'Admin', NULL);


