#
# TABLE STRUCTURE FOR: tb_invoice_vendor
#

DROP TABLE IF EXISTS `tb_invoice_vendor`;

CREATE TABLE `tb_invoice_vendor` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `Date` datetime NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` varchar(15) NOT NULL,
  `ticket_total` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tb_invoice_vendor` (`invoice_id`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (1, '2019-12-17 19:33:58', 4, 300000, 'Normal', 300000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (2, '2019-12-17 19:43:52', 4, 303000, 'Normal', 303000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (3, '2019-12-17 19:51:17', 4, 1500, 'Normal', 1500, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');


#
# TABLE STRUCTURE FOR: tb_invoice_vendor_detell
#

DROP TABLE IF EXISTS `tb_invoice_vendor_detell`;

CREATE TABLE `tb_invoice_vendor_detell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `Name`, `Price`) VALUES (1, 2, 'dfsdfs', 300000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `Name`, `Price`) VALUES (2, 2, 'hahaha', 3000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `Name`, `Price`) VALUES (3, 3, 'hahahah', 600);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `Name`, `Price`) VALUES (4, 3, 'asdasdasdas', 900);


#
# TABLE STRUCTURE FOR: tb_users
#

DROP TABLE IF EXISTS `tb_users`;

CREATE TABLE `tb_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) NOT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_phone` varchar(13) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `permission` varchar(25) NOT NULL,
  `Date_login` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (1, 'ໂຊກໄຊ', 'ແກ້ວພິລາວັນ', '8552077452952', 'ບ້ານ ດອນກອຍ ເມືອງສີສັດຕະນາກ ນະຄອນຫຼວງວຽງຈັນ', 'Admin', 'QWRtaW4=', 'Admin', '2019-12-17');
INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (2, 'ແມັກກີ້', 'ວັງວຽງ', '7777777', 'ວັງວຽງ', 'max', 'MTIzNDU=', 'Employee', NULL);


#
# TABLE STRUCTURE FOR: tb_vendor
#

DROP TABLE IF EXISTS `tb_vendor`;

CREATE TABLE `tb_vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_phone` varchar(13) NOT NULL,
  `vendor_address` varchar(100) NOT NULL,
  `vendor_credit` varchar(50) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tb_vendor` (`vendor_id`, `vendor_name`, `vendor_phone`, `vendor_address`, `vendor_credit`) VALUES (4, 'test', '45122', 'sdfsdfsdfsd', '15');


