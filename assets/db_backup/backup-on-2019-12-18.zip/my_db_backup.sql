#
# TABLE STRUCTURE FOR: tb_invoice_vendor
#

DROP TABLE IF EXISTS `tb_invoice_vendor`;

CREATE TABLE `tb_invoice_vendor` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `rate_name` varchar(20) NOT NULL,
  `Date` datetime NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` varchar(15) NOT NULL,
  `ticket_total` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`invoice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (1, '', '2019-12-17 19:33:58', 4, 300000, 'Normal', 300000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (2, '', '2019-12-17 19:43:52', 4, 303000, 'Normal', 303000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (3, '', '2019-12-17 19:51:17', 4, 1500, 'Normal', 1500, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (4, '', '2019-12-18 00:24:28', 4, 900, 'Normal', 900, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (5, '', '2019-12-18 00:27:13', 4, 33300, 'Normal', 33300, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (6, '', '2019-12-18 00:30:46', 4, 8300, 'Normal', 8300, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (7, '', '2019-12-18 00:31:35', 4, 8300, 'Normal', 8300, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (8, '', '2019-12-18 00:32:29', 4, 8000, 'Normal', 8000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (9, '', '2019-12-18 00:35:57', 4, 2000, 'Normal', 2000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (10, '', '2019-12-18 00:38:02', 4, 50000, 'Normal', 50000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (11, '', '2019-12-18 00:39:14', 4, 50000, 'Normal', 50000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (12, ' ໂດລາ', '2019-12-18 00:44:49', 4, 5000, 'Normal', 5000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (13, ' ບາດ', '2019-12-18 00:46:57', 4, 10000, 'Normal', 10000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');
INSERT INTO `tb_invoice_vendor` (`invoice_id`, `rate_name`, `Date`, `vendor_id`, `amount`, `status`, `ticket_total`, `username`) VALUES (14, ' ບາດ', '2019-12-18 09:11:32', 4, 10000, 'Normal', 10000, 'ໂຊກໄຊ ແກ້ວພິລາວັນ');


#
# TABLE STRUCTURE FOR: tb_invoice_vendor_detell
#

DROP TABLE IF EXISTS `tb_invoice_vendor_detell`;

CREATE TABLE `tb_invoice_vendor_detell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `rate` double NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (1, 2, '8', 'dfsdfs', 300000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (2, 2, '8', 'hahaha', 3000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (3, 3, '8', 'hahahah', 600);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (4, 3, '8', 'asdasdasdas', 900);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (5, 4, '0', '1', 500);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (6, 4, '0', '1', 300);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (7, 4, '0', '1', 100);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (8, 5, '0', '1', 6300);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (9, 5, '0', '1', 23000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (10, 5, '0', '1', 4000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (11, 6, '250', '1', 6300);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (12, 6, '250', '1', 2000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (13, 7, '250', '1', 6300);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (14, 7, '250', '1', 2000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (15, 8, '1', '1', 5000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (16, 8, '1', '1', 3000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (17, 9, '250', '1', 2000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (18, 10, '250', '1', 50000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (19, 11, '1', '1', 50000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (20, 12, '8000', '1', 5000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (21, 13, '250', '1', 6000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (22, 13, '250', '1', 4000);
INSERT INTO `tb_invoice_vendor_detell` (`id`, `invoice_id`, `rate`, `Name`, `Price`) VALUES (23, 14, '250', '1', 10000);


#
# TABLE STRUCTURE FOR: tb_users
#

DROP TABLE IF EXISTS `tb_users`;

CREATE TABLE `tb_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) NOT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_phone` varchar(13) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `permission` varchar(25) NOT NULL,
  `Date_login` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (1, 'ໂຊກໄຊ', 'ແກ້ວພິລາວັນ', '8552077452952', 'ບ້ານ ດອນກອຍ ເມືອງສີສັດຕະນາກ ນະຄອນຫຼວງວຽງຈັນ', 'Admin', 'QWRtaW4=', 'Admin', '2019-12-18');
INSERT INTO `tb_users` (`user_id`, `user_fname`, `user_lname`, `user_phone`, `user_address`, `username`, `password`, `permission`, `Date_login`) VALUES (2, 'ແມັກກີ້', 'ວັງວຽງ', '7777777', 'ວັງວຽງ', 'max', 'MTIzNDU=', 'Employee', NULL);


#
# TABLE STRUCTURE FOR: tb_vendor
#

DROP TABLE IF EXISTS `tb_vendor`;

CREATE TABLE `tb_vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_phone` varchar(13) NOT NULL,
  `vendor_address` varchar(100) NOT NULL,
  `vendor_credit` varchar(50) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tb_vendor` (`vendor_id`, `vendor_name`, `vendor_phone`, `vendor_address`, `vendor_credit`) VALUES (4, 'test', '45122', 'sdfsdfsdfsd', '15');


